/**
 * Configuración global de la aplicación.
 * Este archivo define las variables de entorno y configuraciones
 * necesarias para el funcionamiento del sistema.
 * 
 * @module Configuration
 */
export default () => ({
  port: parseInt(process.env.PORT, 10) || 3001,
  nodeEnv: process.env.NODE_ENV || 'development',
  corsOrigin: process.env.CORS_ORIGIN || '*',
  
  database: {
    users: {
      type: 'postgres',
      host: process.env.DB_HOST || 'dev.telehost.net',
      port: parseInt(process.env.DB_PORT, 10) || 5460,
      username: process.env.DB_USERNAME || 'luis',
      password: process.env.DB_PASSWORD || 'Lam1414*$',
      database: process.env.DB_DATABASE || 'backed',
      retryAttempts: 3,
      retryDelay: 3000,
      ssl: false,
    },
    admin: {
      type: 'postgres',
      host: process.env.ADMIN_DB_HOST || 'dev.telehost.net',
      port: parseInt(process.env.ADMIN_DB_PORT, 10) || 5461,
      username: process.env.ADMIN_DB_USERNAME || 'luis',
      password: process.env.ADMIN_DB_PASSWORD || 'Lam1414*$',
      database: process.env.ADMIN_DB_DATABASE || 'admin',
      retryAttempts: 3,
      retryDelay: 3000,
      ssl: false,
    },
    externa: {
      type: 'postgres',
      host: process.env.EXTERNAL_DB_HOST || 'dev.telehost.net',
      port: parseInt(process.env.EXTERNAL_DB_PORT, 10) || 5436,
      username: process.env.EXTERNAL_DB_USERNAME || 'sabaneta_1',
      password: process.env.EXTERNAL_DB_PASSWORD || 'eccfd36b3efaa4631f7',
      database: process.env.EXTERNAL_DB_NAME || 'gomezmarket_sabaneta',
      retryAttempts: 3,
      retryDelay: 3000,
      ssl: false,
    },
  },

  jwt: {
    secret: process.env.JWT_SECRET || 'tu_secreto_jwt_aqui',
    expiresIn: process.env.JWT_EXPIRATION || '24h',
  },

  evolution: {
    apiUrl: process.env.EVOLUTION_API_URL || 'https://api.zemog.info',
    apiKey: process.env.EVOLUTION_API_KEY || '5A1766001427-4C5A-BAFE-B81812862DA0',
  },

  deepseek: {
    apiKey: process.env.DEEPSEEK_API_KEY || 'sk-87ffab8448be48cbab060033c19994e2',
    model: process.env.DEEPSEEK_MODEL || 'deepseek-chat',
    apiUrl: process.env.DEEPSEEK_API_URL || 'https://api.deepseek.com/v1',
  },

  whatsapp: {
    apiUrl: process.env.WHATSAPP_API_URL || 'https://api.zemog.info',
    instance: process.env.WHATSAPP_INSTANCE || '04245600192',
  },

  ai: {
    apiKey: process.env.AI_API_KEY || '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',
    whisperUrl: 'https://api.openai.com/v1/audio/transcriptions',
    chatUrl: 'https://api.openai.com/v1/chat/completions',
    model: process.env.OPENAI_MODEL || 'gpt-3.5-turbo',
    systemPrompt: process.env.AI_SYSTEM_PROMPT || `Eres un asistente virtual especializado en atención al cliente para una empresa de tecnología. 
Tu objetivo es ayudar a los clientes de manera profesional y amable.

Instrucciones específicas:
1. Responde siempre en español de manera clara y concisa.
2. Mantén un tono profesional pero amigable.
3. Si no sabes algo, sé honesto y ofrece buscar la información.
4. Enfócate en resolver problemas y brindar soluciones.
5. Usa emojis ocasionalmente para hacer la conversación más amena.
6. Si el cliente tiene una queja, muestra empatía y ofrece ayuda inmediata.
7. Si el cliente necesita información técnica, proporciona detalles precisos.
8. Si el cliente quiere hablar con un humano, ofrece la opción de transferir la conversación.

Recuerda: Tu objetivo es brindar la mejor experiencia posible al cliente.`,
  },

  valery: {
    apiUrl: process.env.VALERY_API_URL,
    apiKey: process.env.VALERY_API_KEY,
    syncInterval: parseInt(process.env.VALERY_SYNC_INTERVAL, 10) || 3600000, // 1 hora por defecto
  },
}); 