import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ExternalDbService } from '../external-db/external-db.service';

@Injectable()
export class ValeryDbService {
  private readonly logger = new Logger(ValeryDbService.name);

  constructor(
    private configService: ConfigService,
    private externalDbService: ExternalDbService
  ) {}

  async obtenerProductos(busqueda?: string) {
    try {
      return this.externalDbService.obtenerProductos(busqueda);
    } catch (error) {
      this.logger.error('Error al obtener productos:', error);
      throw error;
    }
  }

  async obtenerFacturasCliente(codigoCliente: string) {
    try {
      const query = `
        SELECT 
          f.numero_factura,
          f.fecha_emision,
          f.subtotal,
          f.iva,
          f.total,
          f.estado,
          f.metodo_pago
        FROM facturas f
        WHERE f.codigo_cliente = $1
        ORDER BY f.fecha_emision DESC
        LIMIT 10
      `;
      
      return this.externalDbService.ejecutarQuery(query, [codigoCliente]);
    } catch (error) {
      this.logger.error('Error al obtener facturas del cliente:', error);
      throw error;
    }
  }

  async obtenerClientePorTelefono(telefono: string) {
    try {
      return this.externalDbService.obtenerClientePorTelefono(telefono);
    } catch (error) {
      this.logger.error('Error al obtener cliente por teléfono:', error);
      throw error;
    }
  }

  async obtenerProductosPorCategoria(categoria: string) {
    try {
      const query = `
        SELECT 
          p.codigo,
          p.nombre,
          p.descripcion,
          p.precio,
          p.precio_iva,
          p.precio_neto
        FROM productos p
        INNER JOIN categorias c ON p.categoria_id = c.id
        WHERE c.nombre = $1 AND p.activo = true
      `;
      
      return this.externalDbService.ejecutarQuery(query, [categoria]);
    } catch (error) {
      this.logger.error('Error al obtener productos por categoría:', error);
      throw error;
    }
  }

  async obtenerStockProducto(codigoProducto: string) {
    try {
      const query = `
        SELECT 
          s.cantidad_disponible,
          s.cantidad_reservada,
          s.ubicacion
        FROM stock s
        WHERE s.codigo_producto = $1
      `;
      
      const resultado = await this.externalDbService.ejecutarQuery(query, [codigoProducto]);
      return resultado[0];
    } catch (error) {
      this.logger.error('Error al obtener stock del producto:', error);
      throw error;
    }
  }

  async crearPedido(datosPedido: any) {
    try {
      // 1. Crear encabezado del pedido
      const encabezadoQuery = `
        INSERT INTO encabedoc (
          codcliente, nombrecliente, rif, telefonos, monedacodigo, 
          moneda, depositocodigo, usuariocodigo, tasa, subtotal, 
          iva, total, esexento, fechaemision, hora, status
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, CURRENT_DATE, CURRENT_TIME, 'PE')
        RETURNING idencabedoc
      `;
      
      const encabezado = await this.externalDbService.ejecutarQuery(encabezadoQuery, [
        datosPedido.codcliente,
        datosPedido.nombrecliente,
        datosPedido.rif,
        datosPedido.telefonos,
        datosPedido.monedacodigo,
        datosPedido.moneda,
        datosPedido.depositocodigo,
        datosPedido.usuariocodigo,
        datosPedido.tasa,
        datosPedido.subtotal,
        datosPedido.iva,
        datosPedido.total,
        datosPedido.esexento
      ]);

      const idencabedoc = encabezado[0].idencabedoc;

      // 2. Crear movimientos del pedido
      for (const item of datosPedido.items) {
        const movimientoQuery = `
          INSERT INTO movimientosdoc (
            idencabedoc, codigo, nombre, descripcionreal, cantidad,
            precio, iva, preciototal, status
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'PE')
        `;
        
        await this.externalDbService.ejecutarQuery(movimientoQuery, [
          idencabedoc,
          item.codigo,
          item.nombre,
          item.descripcion,
          item.cantidad,
          item.precio,
          item.iva,
          item.preciototal
        ]);
      }

      // 3. Crear registro de pago
      const pagoQuery = `
        INSERT INTO pagos (
          idencabedoc, idtipo, monto, codigobanco, banco,
          clienteid, telefono, fechatrans
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, CURRENT_DATE)
      `;
      
      await this.externalDbService.ejecutarQuery(pagoQuery, [
        idencabedoc,
        datosPedido.tipoPago,
        datosPedido.monto,
        datosPedido.codigobanco,
        datosPedido.banco,
        datosPedido.clienteid,
        datosPedido.telefono
      ]);

      return idencabedoc;
    } catch (error) {
      this.logger.error('Error al crear pedido:', error);
      throw error;
    }
  }

  async obtenerMetodosPago() {
    try {
      const query = `
        SELECT idtipo, pago
        FROM tipopagos
        WHERE status = 'SI'
      `;
      
      return this.externalDbService.ejecutarQuery(query);
    } catch (error) {
      this.logger.error('Error al obtener métodos de pago:', error);
      throw error;
    }
  }

  async obtenerBancos() {
    try {
      const query = `
        SELECT codigo, banco
        FROM bancos
        WHERE status = 'SI'
      `;
      
      return this.externalDbService.ejecutarQuery(query);
    } catch (error) {
      this.logger.error('Error al obtener bancos:', error);
      throw error;
    }
  }

  async actualizarEstadoPedido(idencabedoc: number, nuevoEstado: string) {
    try {
      const encabezadoQuery = `
        UPDATE encabedoc
        SET status = $1
        WHERE idencabedoc = $2
      `;
      
      await this.externalDbService.ejecutarQuery(encabezadoQuery, [nuevoEstado, idencabedoc]);

      const movimientoQuery = `
        UPDATE movimientosdoc
        SET status = $1
        WHERE idencabedoc = $2
      `;
      
      await this.externalDbService.ejecutarQuery(movimientoQuery, [nuevoEstado, idencabedoc]);
    } catch (error) {
      this.logger.error('Error al actualizar estado del pedido:', error);
      throw error;
    }
  }

  async asignarDelivery(idencabedoc: number, idcolaborador: number, direccion: string, telefono: string) {
    try {
      const query = `
        INSERT INTO delivery (
          idencabedoc, idcolaborador, direccion, telefono,
          fechaasignacion, status
        ) VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP, 'PE')
      `;
      
      await this.externalDbService.ejecutarQuery(query, [
        idencabedoc,
        idcolaborador,
        direccion,
        telefono
      ]);
    } catch (error) {
      this.logger.error('Error al asignar delivery:', error);
      throw error;
    }
  }

  // Método para ejecutar queries personalizadas
  async ejecutarQuery(query: string, params: any[] = []) {
    try {
      return this.externalDbService.ejecutarQuery(query, params);
    } catch (error) {
      this.logger.error(`Error al ejecutar query: ${query}`, error);
      throw error;
    }
  }
} 