import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ValeryDbService } from './valery-db.service';

interface EstadoChat {
  paso: number;
  cliente?: any;
  productos: any[];
  metodoPago?: any;
  banco?: any;
  total: number;
  subtotal: number;
  iva: number;
  tipoEntrega?: string;
  direccionEntrega?: string;
  cedulaRifIngresada?: string;
  nombreCompletoIngresado?: string;
  carritoCompras: any[];
  idPedidoCreado?: string;
  comprobanteInfo?: string;
  ocrMontoReportado?: string;
  ocrReferenciaReportada?: string;
  modoDebug?: boolean;
}

// Interfaz para almacenar datos de la sesión del cliente
interface ClientSession {
  phoneNumber: string;
  clientId?: string;
  clientName?: string;
  identificationNumber?: string;
  isAuthenticated: boolean;
  lastActivity: Date;
  context: string; // 'initial', 'auth', 'menu', 'product_search', 'order', etc.
}

@Injectable()
export class ValeryChatbotService {
  private readonly logger = new Logger(ValeryChatbotService.name);
  private estadosChat: Map<string, EstadoChat> = new Map();
  private activeSessions = new Map<string, ClientSession>();

  constructor(
    private readonly configService: ConfigService,
    private valeryDbService: ValeryDbService
  ) {
    this.logger.log('ValeryChatbotService inicializado - Usando conexión directa a la base de datos');
  }

  async handleMessage(message: string, phoneNumber: string, chatbotId: string): Promise<string> {
    try {
      this.logger.debug(`Procesando mensaje de ${phoneNumber}: ${message}`);
      
      // Verificar si ya existe una sesión para este número
      let session = this.getSession(phoneNumber);
      
      // Si no existe sesión, crear una nueva
      if (!session) {
        session = this.createSession(phoneNumber);
        return this.getWelcomeMessage();
      }
      
      // Actualizar timestamp de actividad
      session.lastActivity = new Date();
      
      // Si el mensaje parece ser una cédula y el usuario no está autenticado
      if (this.isIdentificationNumber(message) && !session.isAuthenticated) {
        return this.authenticateClient(message, session);
      }
      
      // Si el usuario está autenticado, procesar mensaje según el contexto
      if (session.isAuthenticated) {
        return this.processAuthenticatedMessage(message, session, chatbotId);
      }
      
      // Si llegamos aquí, es un usuario no autenticado con un mensaje que no es cédula
      return "Por favor, ingresa tu número de cédula para poder identificarte y ofrecerte un mejor servicio.";
    } catch (error) {
      this.logger.error(`Error al procesar mensaje: ${error}`);
      return "Lo siento, ocurrió un error al procesar tu mensaje. Por favor, intenta nuevamente.";
    }
  }

  private getSession(phoneNumber: string): ClientSession | undefined {
    return this.activeSessions.get(phoneNumber);
  }

  private createSession(phoneNumber: string): ClientSession {
    const session: ClientSession = {
      phoneNumber,
      isAuthenticated: false,
      lastActivity: new Date(),
      context: 'initial'
    };
    
    this.activeSessions.set(phoneNumber, session);
    return session;
  }

  private getWelcomeMessage(): string {
    return "👋 ¡Bienvenido al chat de atención al cliente! Por favor, ingresa tu número de cédula para identificarte.";
  }

  private isIdentificationNumber(message: string): boolean {
    // Patrón para cédulas venezolanas: V-números o solo números
    const cedula = message.trim().toUpperCase();
    return /^V?\d+$/i.test(cedula) || /^V[-.]?\d+$/i.test(cedula);
  }

  private async authenticateClient(cedula: string, session: ClientSession): Promise<string> {
    try {
      // Normalizar cédula (quitar V-, dejar solo números)
      const normalizedCedula = this.normalizeIdentification(cedula);
      
      // Buscar cliente por cédula en la base de datos
      const query = `
        SELECT 
          c.idcliente,
          c.codigocliente,
          c.nombre,
          c.rif,
          c.direccion1,
          c.direccion2,
          c.telefono1,
          c.telefono2,
          c.email,
          c.tienecredito,
          c.diascredito,
          c.saldo,
          c.status
        FROM clientes c
        WHERE c.rif = $1 OR c.rif = $2
      `;
      
      const results = await this.valeryDbService.ejecutarQuery(query, [normalizedCedula, `V${normalizedCedula}`]);
      
      if (results && results.length > 0) {
        const cliente = results[0];
        
        // Actualizar información de la sesión
        session.clientId = cliente.codigocliente;
        session.clientName = cliente.nombre;
        session.identificationNumber = normalizedCedula;
        session.isAuthenticated = true;
        session.context = 'menu';
        
        // Mensaje de bienvenida personalizado
        return `¡Bienvenido ${cliente.nombre}! Has sido identificado correctamente.\n\n¿Cómo puedo ayudarte hoy?\n\n1️⃣ Consultar productos\n2️⃣ Ver mi saldo\n3️⃣ Historial de facturas\n4️⃣ Hacer un pedido`;
      } else {
        return "No hemos encontrado ningún cliente con esa cédula. Por favor, verifica el número o comunícate con nuestro servicio al cliente para registrarte.";
      }
    } catch (error) {
      this.logger.error(`Error al autenticar cliente: ${error}`);
      return "Lo siento, hubo un problema al verificar tu identidad. Por favor, intenta nuevamente o comunícate con servicio al cliente.";
    }
  }

  private normalizeIdentification(cedula: string): string {
    // Quitar 'V', '-', espacios y puntos
    return cedula.trim().toUpperCase().replace(/^V[-.]?\s*/i, '').replace(/[^0-9]/g, '');
  }

  private async processAuthenticatedMessage(message: string, session: ClientSession, chatbotId: string): Promise<string> {
    // Si estamos en el menú principal, procesar opciones numéricas
    if (session.context === 'menu') {
      switch (message) {
        case '1':
        case '1️⃣':
          session.context = 'product_search';
          return "Por favor, indica qué producto estás buscando.";
        
        case '2':
        case '2️⃣':
          return this.getSaldoCliente(session);
        
        case '3':
        case '3️⃣':
          return this.getHistorialFacturas(session);
        
        case '4':
        case '4️⃣':
          session.context = 'order_start';
          return "Para crear un nuevo pedido, envía los productos que deseas comprar.";
          
        default:
          // Si estamos en el menú pero el mensaje no coincide con ninguna opción,
          // asumimos que es una búsqueda de producto
          session.context = 'product_search';
          return this.searchProducts(message, session);
      }
    }
    
    // Si estamos en contexto de búsqueda de productos
    if (session.context === 'product_search') {
      return this.searchProducts(message, session);
    }
    
    // Para otros contextos, por defecto devolvemos al menú principal
    session.context = 'menu';
    return `Hola ${session.clientName}, ¿en qué puedo ayudarte?\n\n1️⃣ Consultar productos\n2️⃣ Ver mi saldo\n3️⃣ Historial de facturas\n4️⃣ Hacer un pedido`;
  }

  private async getSaldoCliente(session: ClientSession): Promise<string> {
    try {
      if (!session.clientId) {
        return "No se encontró información de tu cuenta. Por favor, intenta identificarte nuevamente.";
      }
      
      const query = `
        SELECT 
          c.nombre,
          c.tienecredito,
          c.diascredito,
          c.saldo
        FROM clientes c
        WHERE c.codigocliente = $1
      `;
      
      const results = await this.valeryDbService.ejecutarQuery(query, [session.clientId]);
      
      if (results && results.length > 0) {
        const cliente = results[0];
        
        if (!cliente.tienecredito) {
          return `Hola ${cliente.nombre}, no tienes una línea de crédito activa.`;
        }
        
        return `Hola ${cliente.nombre}, tu saldo actual es de ${this.formatearPrecio(cliente.saldo)}. Tienes un crédito a ${cliente.diascredito} días.`;
      } else {
        return "No pudimos encontrar información de tu saldo. Por favor, comunícate con servicio al cliente.";
      }
    } catch (error) {
      this.logger.error(`Error al consultar saldo: ${error}`);
      return "Lo siento, hubo un problema al consultar tu saldo. Por favor, intenta más tarde.";
    }
  }

  private async getHistorialFacturas(session: ClientSession): Promise<string> {
    try {
      if (!session.clientId) {
        return "No se encontró información de tu cuenta. Por favor, intenta identificarte nuevamente.";
      }
      
      const query = `
        SELECT 
          f.numero_factura,
          f.fecha_emision,
          f.subtotal,
          f.iva,
          f.total,
          f.estado,
          f.metodo_pago
        FROM facturas f
        WHERE f.codigo_cliente = $1
        ORDER BY f.fecha_emision DESC
        LIMIT 5
      `;
      
      const facturas = await this.valeryDbService.ejecutarQuery(query, [session.clientId]);
      
      if (!facturas || facturas.length === 0) {
        return `Hola ${session.clientName}, no encontramos facturas recientes asociadas a tu cuenta.`;
      }
      
      let respuesta = `Hola ${session.clientName}, estas son tus facturas recientes:\n\n`;
      
      facturas.forEach((factura, index) => {
        respuesta += `${index + 1}. Factura #${factura.numero_factura}\n`;
        respuesta += `   Fecha: ${new Date(factura.fecha_emision).toLocaleDateString()}\n`;
        respuesta += `   Total: ${this.formatearPrecio(factura.total)}\n`;
        respuesta += `   Estado: ${this.traducirEstadoFactura(factura.estado)}\n\n`;
      });
      
      return respuesta;
    } catch (error) {
      this.logger.error(`Error al consultar facturas: ${error}`);
      return "Lo siento, hubo un problema al consultar tus facturas. Por favor, intenta más tarde.";
    }
  }

  private async searchProducts(busqueda: string, session: ClientSession): Promise<string> {
    try {
      // Lista ampliada de palabras y expresiones comunes a ignorar en las búsquedas
      const palabrasAIgnorar = [
        // Palabras de pregunta/consulta
        'buscar', 'producto', 'precio', 'de', 'el', 'la', 'los', 'las', 'un', 'una', 'unos', 'unas', 
        // Expresiones comunes de solicitud
        'hay', 'tienen', 'venden', 'tienes', 'tendras', 'tendrás', 'ay', 'habrá', 'habra',
        // Verbos comunes
        'quiero', 'necesito', 'quisiera', 'dame', 'me', 'puedes', 'podrias', 'podrías', 'dar',
        // Frases comunes
        'me puedes', 'me podrias', 'me podrías', 'me das', 'me darías', 'me darias', 
        'necesito que', 'quisiera que', 'por favor', 'porfavor', 'porfa',
        // Artículos y preposiciones adicionales
        'del', 'al', 'con', 'sin', 'para', 'por', 'en', 'a'
      ];
      
      // Normalizar texto: convertir a minúsculas y eliminar caracteres especiales
      const busquedaNormalizada = busqueda.toLowerCase()
        .normalize("NFD").replace(/[\u0300-\u036f]/g, "") // Eliminar acentos
        .replace(/[^\w\s]/gi, ' '); // Reemplazar caracteres especiales por espacios
      
      // Tokenizar y filtrar palabras a ignorar
      const terminoBusqueda = busquedaNormalizada
        .split(/\s+/) // Dividir por uno o más espacios
        .filter(palabra => {
          // Mantener solo palabras que no están en la lista de ignoradas y tienen al menos 2 caracteres
          return !palabrasAIgnorar.includes(palabra.toLowerCase()) && palabra.length >= 2;
        })
        .join(' ')
        .trim();
      
      if (!terminoBusqueda) {
        return "Por favor, especifica qué producto estás buscando.";
      }
      
      // Buscar productos usando el servicio de base de datos
      const productos = await this.valeryDbService.obtenerProductos(terminoBusqueda);
      
      if (!productos || productos.length === 0) {
        return `Lo siento, no encontramos productos que coincidan con "${terminoBusqueda}". ¿Quieres buscar con otro nombre?`;
      }
      
      // Limitar resultados
      const productosLimitados = productos.slice(0, 5);
      let respuesta = `Encontramos ${productos.length} productos relacionados con "${terminoBusqueda}":\n\n`;
      
      productosLimitados.forEach((producto, index) => {
        respuesta += `${index + 1}. *${producto.nombre}*\n`;
        respuesta += `   Precio: ${this.formatearPrecio(producto.preciounidad)}\n`;
        respuesta += `   Disponible: ${producto.existenciaunidad} unidades\n\n`;
      });
      
      if (productos.length > 5) {
        respuesta += `... y ${productos.length - 5} productos más. Por favor, especifica más tu búsqueda para ver resultados más precisos.`;
      }
      
      // Volver al contexto del menú después de mostrar los resultados
      session.context = 'menu';
      respuesta += "\n\nPuedes escribir un número del 1 al 4 para acceder a otras opciones.";
      
      return respuesta;
    } catch (error) {
      this.logger.error(`Error al buscar productos: ${error}`);
      return "Lo siento, ocurrió un error al buscar productos. Por favor, intenta más tarde.";
    }
  }

  private formatearPrecio(precio: number): string {
    return new Intl.NumberFormat('es-VE', { style: 'currency', currency: 'USD' }).format(precio);
  }
  
  private traducirEstadoFactura(estado: string): string {
    const estados = {
      'PAID': 'Pagada',
      'PENDING': 'Pendiente',
      'CANCELLED': 'Cancelada',
      'PARTIAL': 'Pago parcial'
    };
    
    return estados[estado] || estado;
  }

  // Método para limpiar sesiones antiguas (podría ejecutarse periódicamente)
  cleanupSessions(maxInactiveMinutes: number = 60): void {
    const now = new Date();
    
    for (const [phoneNumber, session] of this.activeSessions.entries()) {
      const inactiveTime = (now.getTime() - session.lastActivity.getTime()) / (1000 * 60);
      
      if (inactiveTime > maxInactiveMinutes) {
        this.activeSessions.delete(phoneNumber);
        this.logger.debug(`Sesión eliminada para ${phoneNumber} por inactividad`);
      }
    }
  }
}
