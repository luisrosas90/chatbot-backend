import { Module } from '@nestjs/common';
import { ValeryService } from './valery.service';
import { ValeryChatbotService } from './valery-chatbot.service';
import { ValeryDbService } from './valery-db.service';
import { ConfigModule } from '@nestjs/config';
import { ExternalDbModule } from '../external-db/external-db.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Product } from '../products/entities/product.entity';
import { Invoice } from '../invoices/entities/invoice.entity';
import { User } from '../users/entities/user.entity';
import { ProductsModule } from '../products/products.module';

@Module({
  imports: [
    ConfigModule,
    ExternalDbModule,
    TypeOrmModule.forFeature([Invoice, User], 'users'),
    ProductsModule
  ],
  providers: [
    ValeryService,
    ValeryChatbotService,
    ValeryDbService
  ],
  exports: [
    ValeryService,
    ValeryChatbotService,
    ValeryDbService
  ],
})
export class ValeryModule {} 