import { Controller, Get, Post, Put, Delete, Body, Param, Query, Logger } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiQuery } from '@nestjs/swagger';
import { ChatbotService } from '../services/chatbot.service';
import { ConversationService } from '../services/conversation.service';
import { PromotionService } from '../services/promotion.service';
import { ReportService } from '../services/report.service';
import { CreateChatbotDto } from '../dto/create-chatbot.dto';
import { UpdateChatbotDto } from '../dto/update-chatbot.dto';
import { CreatePromotionDto } from '../dto/create-promotion.dto';
import { UpdatePromotionDto } from '../dto/update-promotion.dto';

@ApiTags('admin')
@Controller('admin')
export class AdminController {
  private readonly logger = new Logger(AdminController.name);

  constructor(
    private readonly chatbotService: ChatbotService,
    private readonly conversationService: ConversationService,
    private readonly promotionService: PromotionService,
    private readonly reportService: ReportService,
  ) {}

  // Chatbot endpoints
  @Post('chatbots')
  @ApiOperation({ summary: 'Crear un nuevo chatbot' })
  @ApiResponse({ status: 201, description: 'Chatbot creado exitosamente' })
  create(@Body() createChatbotDto: CreateChatbotDto) {
    return this.chatbotService.create(createChatbotDto);
  }

  @Get('chatbots')
  @ApiOperation({ summary: 'Obtener todos los chatbots' })
  @ApiResponse({ status: 200, description: 'Lista de chatbots obtenida exitosamente' })
  findAll() {
    return this.chatbotService.findAll();
  }

  @Get('chatbots/:id')
  @ApiOperation({ summary: 'Obtener un chatbot por ID' })
  @ApiResponse({ status: 200, description: 'Chatbot encontrado exitosamente' })
  findOne(@Param('id') id: string) {
    return this.chatbotService.findOne(id);
  }

  @Put('chatbots/:id')
  @ApiOperation({ summary: 'Actualizar un chatbot' })
  @ApiResponse({ status: 200, description: 'Chatbot actualizado exitosamente' })
  update(@Param('id') id: string, @Body() updateChatbotDto: UpdateChatbotDto) {
    return this.chatbotService.update(id, updateChatbotDto);
  }

  @Delete('chatbots/:id')
  @ApiOperation({ summary: 'Eliminar un chatbot' })
  @ApiResponse({ status: 200, description: 'Chatbot eliminado exitosamente' })
  remove(@Param('id') id: string) {
    return this.chatbotService.remove(id);
  }

  @Put('chatbots/:id/toggle')
  @ApiOperation({ summary: 'Activar/desactivar un chatbot' })
  @ApiResponse({ status: 200, description: 'Estado del chatbot actualizado exitosamente' })
  toggleActive(@Param('id') id: string) {
    return this.chatbotService.toggleActive(id);
  }

  // Conversation endpoints
  @Get('conversations')
  @ApiOperation({ summary: 'Obtener todas las conversaciones' })
  @ApiResponse({ status: 200, description: 'Lista de conversaciones obtenida exitosamente' })
  findAllConversations() {
    return this.conversationService.findAll();
  }

  @Get('conversations/active')
  @ApiOperation({ summary: 'Obtener conversaciones activas' })
  @ApiResponse({ status: 200, description: 'Lista de conversaciones activas' })
  async getActiveConversations() {
    this.logger.log('Obteniendo conversaciones activas');
    return this.conversationService.findActiveConversations();
  }

  @Get('conversations/abandoned')
  @ApiOperation({ summary: 'Obtener carritos abandonados' })
  @ApiResponse({ status: 200, description: 'Lista de carritos abandonados' })
  async getAbandonedCarts() {
    this.logger.log('Obteniendo carritos abandonados');
    return this.conversationService.findAbandonedCarts();
  }

  @Get('conversations/:id')
  @ApiOperation({ summary: 'Obtener una conversación por ID' })
  @ApiResponse({ status: 200, description: 'Conversación encontrada exitosamente' })
  findOneConversation(@Param('id') id: string) {
    return this.conversationService.findOne(id);
  }

  @Post('conversations/:id/block')
  @ApiOperation({ summary: 'Bloquear conversación' })
  @ApiResponse({ status: 200, description: 'Conversación bloqueada exitosamente' })
  async blockConversation(
    @Param('id') id: string,
    @Body('reason') reason: string
  ) {
    this.logger.log(`Bloqueando conversación ${id}`);
    const conversation = await this.conversationService.findOne(id);
    return this.conversationService.blockConversation(conversation, reason);
  }

  @Post('conversations/:id/unblock')
  @ApiOperation({ summary: 'Desbloquear conversación' })
  @ApiResponse({ status: 200, description: 'Conversación desbloqueada exitosamente' })
  async unblockConversation(@Param('id') id: string) {
    this.logger.log(`Desbloqueando conversación ${id}`);
    const conversation = await this.conversationService.findOne(id);
    return this.conversationService.unblockConversation(conversation);
  }

  // Promotion endpoints
  @Post('promotions')
  createPromotion(@Body() createPromotionDto: CreatePromotionDto) {
    return this.promotionService.create(createPromotionDto);
  }

  @Get('promotions')
  findAllPromotions() {
    return this.promotionService.findAll();
  }

  @Get('promotions/active')
  @ApiOperation({ summary: 'Obtener promociones activas' })
  @ApiResponse({ status: 200, description: 'Lista de promociones activas' })
  async getActivePromotions() {
    this.logger.log('Obteniendo promociones activas');
    return this.promotionService.findActive();
  }

  @Get('promotions/:id')
  @ApiOperation({ summary: 'Obtener una promoción por ID' })
  @ApiResponse({ status: 200, description: 'Promoción encontrada exitosamente' })
  findOnePromotion(@Param('id') id: string) {
    return this.promotionService.findOne(id);
  }

  @Put('promotions/:id')
  @ApiOperation({ summary: 'Actualizar promoción' })
  @ApiResponse({ status: 200, description: 'Promoción actualizada exitosamente' })
  async updatePromotion(
    @Param('id') id: string,
    @Body() updatePromotionDto: UpdatePromotionDto
  ) {
    this.logger.log(`Actualizando promoción ${id}`);
    return this.promotionService.update(id, updatePromotionDto);
  }

  @Delete('promotions/:id')
  @ApiOperation({ summary: 'Eliminar promoción' })
  @ApiResponse({ status: 200, description: 'Promoción eliminada exitosamente' })
  removePromotion(@Param('id') id: string) {
    return this.promotionService.remove(id);
  }

  // Report endpoints
  @Get('reports/sales')
  @ApiOperation({ summary: 'Obtener reporte de ventas' })
  @ApiQuery({ name: 'startDate', required: true, type: Date })
  @ApiQuery({ name: 'endDate', required: true, type: Date })
  @ApiResponse({ status: 200, description: 'Reporte de ventas obtenido exitosamente' })
  getSalesReport(
    @Query('startDate') startDate: Date,
    @Query('endDate') endDate: Date
  ) {
    return this.reportService.getSalesReport(startDate, endDate);
  }

  @Get('reports/conversations')
  @ApiOperation({ summary: 'Obtener reporte de conversaciones' })
  @ApiQuery({ name: 'startDate', required: true, type: Date })
  @ApiQuery({ name: 'endDate', required: true, type: Date })
  @ApiResponse({ status: 200, description: 'Reporte de conversaciones obtenido exitosamente' })
  getConversationReport(
    @Query('startDate') startDate: Date,
    @Query('endDate') endDate: Date
  ) {
    return this.reportService.getConversationReport(startDate, endDate);
  }

  @Get('reports/promotions')
  @ApiOperation({ summary: 'Obtener reporte de promociones' })
  @ApiQuery({ name: 'startDate', required: true, type: Date })
  @ApiQuery({ name: 'endDate', required: true, type: Date })
  @ApiResponse({ status: 200, description: 'Reporte de promociones obtenido exitosamente' })
  getPromotionReport(
    @Query('startDate') startDate: Date,
    @Query('endDate') endDate: Date
  ) {
    return this.reportService.getPromotionReport(startDate, endDate);
  }

  @Get('reports/users')
  @ApiOperation({ summary: 'Obtener reporte de usuarios' })
  @ApiResponse({ status: 200, description: 'Reporte de usuarios obtenido exitosamente' })
  getUserReport() {
    return this.reportService.getUserReport();
  }
} 