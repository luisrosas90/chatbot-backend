import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('promotions')
export class Promotion {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @Column()
  description: string;

  @Column({ unique: true })
  code: string;

  @Column('decimal', { precision: 10, scale: 2 })
  discountAmount: number;

  @Column()
  discountType: 'percentage' | 'fixed';

  @Column()
  isActive: boolean;

  @Column()
  startDate: Date;

  @Column()
  endDate: Date;

  @Column('decimal', { precision: 10, scale: 2, nullable: true })
  minimumPurchaseAmount: number;

  @Column('decimal', { precision: 10, scale: 2, nullable: true })
  maximumDiscount: number;

  @Column('int', { default: 0 })
  usageLimit: number;

  @Column('jsonb', { default: { usageCount: 0, lastUsed: null } })
  metadata: {
    usageCount: number;
    lastUsed: Date | null;
  };

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
} 