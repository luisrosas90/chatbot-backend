import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AdminMessage } from './entities/message.entity';
import { Conversation } from './entities/conversation.entity';
import { Chatbot } from './entities/chatbot.entity';
import { ConversationService } from './services/conversation.service';
import { ReportService } from './services/report.service';
import { ChatbotService } from './services/chatbot.service';
import { PromotionService } from './services/promotion.service';
import { AdminController } from './controllers/admin.controller';
import { User } from './entities/user.entity';
import { Promotion } from './entities/promotion.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      AdminMessage,
      Conversation,
      Chatbot,
      User,
      Promotion,
    ], 'users'),
  ],
  controllers: [AdminController],
  providers: [
    ConversationService,
    ReportService,
    ChatbotService,
    PromotionService,
  ],
  exports: [
    ConversationService,
    ReportService,
    ChatbotService,
    PromotionService,
    TypeOrmModule
  ],
})
export class AdminModule {} 