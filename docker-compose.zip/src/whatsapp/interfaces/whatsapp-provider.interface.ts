export interface WhatsAppMessage {
  from: string;
  to: string;
  body: string;
  timestamp: Date;
  type: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'system';
  instanceId: string;
  messageId?: string;
  status?: string;
  metadata?: any;
}

export interface WhatsAppProvider {
  initialize(config?: any): Promise<void>;
  disconnect(config?: any): Promise<void>;
  sendMessage(to: string, message: string, config?: any): Promise<WhatsAppMessage>;
  sendImage(to: string, imageUrl: string, caption: string, config?: any): Promise<WhatsAppMessage>;
  sendDocument(to: string, documentUrl: string, caption: string, config?: any): Promise<WhatsAppMessage>;
  sendAudio(to: string, audioUrl: string, config?: any): Promise<WhatsAppMessage>;
  sendLocation(to: string, latitude: number, longitude: number, config?: any): Promise<WhatsAppMessage>;
  getQRCode(config?: any): Promise<string>;
  updateConfig(config: any): Promise<void>;
  getConfig(config?: any): Promise<any>;
} 