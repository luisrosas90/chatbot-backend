/**
 * Módulo que maneja las sesiones y mensajes de chat.
 * Este módulo proporciona:
 * - Servicio para gestionar sesiones y mensajes
 * - Entidades para almacenar datos de chat
 * - Integración con servicios de IA
 * 
 * @module ChatModule
 */
import { Module, forwardRef } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';
import { ChatService } from './chat.service';
import { ChatSession } from './entities/chat-session.entity';
import { ChatMessage } from './entities/message.entity';
import { AiModule } from '../ai/ai.module';
import { WhatsappModule } from '../whatsapp/whatsapp.module';
import { ValeryModule } from '../valery/valery.module';
import { Chatbot } from '../admin/entities/chatbot.entity';

@Module({
  imports: [
    ConfigModule,
    TypeOrmModule.forFeature([ChatSession, ChatMessage, Chatbot], 'users'),
    AiModule,
    ValeryModule,
    forwardRef(() => WhatsappModule),
  ],
  providers: [ChatService],
  exports: [ChatService],
})
export class ChatModule {} 