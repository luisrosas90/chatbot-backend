/**
 * Servicio para manejar las interacciones de chat con IA.
 * Este servicio gestiona las sesiones de chat, procesa mensajes y genera
 * respuestas utilizando modelos de IA.
 * 
 * @class ChatService
 */
import { Injectable, Logger, Inject, forwardRef } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ChatSession } from './entities/chat-session.entity';
import { ChatMessage } from './entities/message.entity';
import { AiService } from '../ai/ai.service';
import { WhatsappService } from '../whatsapp/whatsapp.service';
import { ValeryChatbotService } from '../valery/valery-chatbot.service';
import { ConfigService } from '@nestjs/config';
import { Chatbot } from '../admin/entities/chatbot.entity';

@Injectable()
export class ChatService {
  private readonly logger = new Logger(ChatService.name);
  private readonly defaultInstanceId: string;

  constructor(
    @InjectRepository(ChatSession, 'users')
    private chatSessionRepository: Repository<ChatSession>,
    @InjectRepository(ChatMessage, 'users')
    private messageRepository: Repository<ChatMessage>,
    @InjectRepository(Chatbot, 'users')
    private chatbotRepository: Repository<Chatbot>,
    private aiService: AiService,
    @Inject(forwardRef(() => WhatsappService))
    private whatsappService: WhatsappService,
    private valeryChatbotService: ValeryChatbotService,
    private configService: ConfigService
  ) {
    this.defaultInstanceId = this.configService.get<string>('WHATSAPP_DEFAULT_INSTANCE');
  }

  /**
   * Procesa un mensaje entrante y genera una respuesta.
   * Este método maneja todo el flujo de chat, incluyendo:
   * - Creación/búsqueda de sesión de chat
   * - Guardado del mensaje del usuario
   * - Generación de respuesta con IA
   * - Envío de la respuesta por WhatsApp
   * - Guardado del historial
   * 
   * @param {string} phoneNumber - Número de teléfono del usuario
   * @param {string} message - Contenido del mensaje
   * @param {string} chatbotId - ID del chatbot
   * @returns {Promise<string>} Respuesta generada por IA
   * @throws {Error} Si hay un error en el procesamiento
   */
  async handleMessage(phoneNumber: string, message: string, chatbotId: string) {
    try {
      // Verificar que el chatbot existe
      const chatbot = await this.chatbotRepository.findOne({
        where: { id: chatbotId, isActive: true }
      });

      if (!chatbot) {
        this.logger.error(`Chatbot no encontrado o inactivo: ${chatbotId}`);
        return "Error: Chatbot no encontrado o inactivo";
      }

      // Procesar el mensaje con ValeryChatbotService usando el nuevo método
      const response = await this.valeryChatbotService.handleMessage(
        message,
        phoneNumber,
        chatbotId
      );

      // Verificar la configuración de WhatsApp del chatbot
      if (!chatbot.settings?.whatsapp?.instanceId) {
        this.logger.error(`No hay instanceId configurado para el chatbot ${chatbotId}`);
        throw new Error('No hay ID de instancia configurado para este chatbot');
      }

      // Enviar respuesta usando el servicio de WhatsApp
      await this.whatsappService.sendMessage(
        phoneNumber,
        response,
        chatbotId
      );

      return response;
    } catch (error) {
      this.logger.error(`Error procesando mensaje: ${error.message}`);
      return `Error procesando su mensaje: ${error.message}`;
    }
  }

  /**
   * Obtiene un chatbot por su ID.
   * 
   * @param {string} chatbotId - ID del chatbot
   * @returns {Promise<Chatbot>} Información del chatbot
   * @throws {Error} Si hay un error al obtener el chatbot
   */
  async getChatbotById(chatbotId: string) {
    try {
      return await this.chatbotRepository.findOne({
        where: { id: chatbotId, isActive: true }
      });
    } catch (error) {
      this.logger.error(`Error obteniendo chatbot: ${error.message}`);
      throw error;
    }
  }

  /**
   * Obtiene el historial de chat para un número de teléfono.
   * 
   * @param {string} phoneNumber - Número de teléfono del usuario
   * @returns {Promise<ChatSession>} Sesión de chat con mensajes
   * @throws {Error} Si hay un error al obtener el historial
   */
  async getChatHistory(phoneNumber: string) {
    try {
      return await this.chatSessionRepository.findOne({
        where: { phoneNumber },
        relations: ['messages'],
        order: {
          messages: {
            timestamp: 'ASC',
          },
        },
      });
    } catch (error) {
      this.logger.error(`Error obteniendo historial de chat: ${error.message}`);
      throw error;
    }
  }

  /**
   * Finaliza una sesión de chat activa.
   * 
   * @param {string} phoneNumber - Número de teléfono del usuario
   * @returns {Promise<void>}
   * @throws {Error} Si hay un error al finalizar la sesión
   */
  async endChatSession(phoneNumber: string) {
    try {
      const session = await this.chatSessionRepository.findOne({
        where: { phoneNumber, status: 'active' },
      });

      if (session) {
        session.status = 'ended';
        session.endTime = new Date();
        await this.chatSessionRepository.save(session);
      }
    } catch (error) {
      this.logger.error(`Error finalizando sesión de chat: ${error.message}`);
      throw error;
    }
  }
} 