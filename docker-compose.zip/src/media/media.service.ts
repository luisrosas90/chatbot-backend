import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import axios from 'axios';
import * as fs from 'fs';
import * as path from 'path';
import * as ffmpeg from 'fluent-ffmpeg';
import * as ffmpegInstaller from '@ffmpeg-installer/ffmpeg';
import { SpeechClient } from '@google-cloud/speech';
import { ImageAnnotatorClient } from '@google-cloud/vision';
import * as crypto from 'crypto';
import * as FormData from 'form-data';
import * as hkdf from 'futoin-hkdf';
import * as mime from 'mime-types';

@Injectable()
export class MediaService {
  private readonly logger = new Logger(MediaService.name);
  private readonly speechClient: SpeechClient;
  private readonly visionClient: ImageAnnotatorClient;
  private readonly tempDir: string;
  private readonly apiKey: string;
  private readonly whisperUrl: string;
  private readonly uploadDir: string;
  private readonly allowedTypes: string[];

  constructor(private configService: ConfigService) {
    ffmpeg.setFfmpegPath(ffmpegInstaller.path);
    this.speechClient = new SpeechClient();
    this.visionClient = new ImageAnnotatorClient();
    this.tempDir = path.join(process.cwd(), 'temp');
    this.apiKey = this.configService.get<string>('ai.apiKey');
    this.whisperUrl = this.configService.get<string>('ai.whisperUrl');
    this.uploadDir = this.configService.get<string>('UPLOAD_DIR') || 'uploads';
    this.allowedTypes = [
      'image/jpeg',
      'image/png',
      'image/gif',
      'audio/mpeg',
      'audio/wav',
      'video/mp4',
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    
    // Crear directorio temporal si no existe
    if (!fs.existsSync(this.tempDir)) {
      fs.mkdirSync(this.tempDir);
    }

    // Crear directorio de uploads si no existe
    if (!fs.existsSync(this.uploadDir)) {
      fs.mkdirSync(this.uploadDir, { recursive: true });
    }
  }

  private async downloadFile(url: string, filePath: string, mediaKey?: string): Promise<void> {
    try {
      this.logger.log(`Iniciando descarga desde: ${url}`);
      
      const response = await axios({
        method: 'GET',
        url: url,
        responseType: 'arraybuffer',
        headers: {
          'User-Agent': 'WhatsApp/2.23.24.82 A',
          'Accept': '*/*',
          'Accept-Language': 'en-US,en;q=0.5',
          'Accept-Encoding': 'gzip, deflate, br',
          'Connection': 'keep-alive',
          'apikey': this.apiKey
        },
        maxContentLength: Infinity,
        maxBodyLength: Infinity
      });

      // Convertir la respuesta a base64
      const base64Data = Buffer.from(response.data).toString('base64');
      
      // Si hay mediaKey, descifrar el contenido
      if (mediaKey) {
        const decryptedData = await this.decryptBase64(base64Data, mediaKey);
        fs.writeFileSync(filePath, Buffer.from(decryptedData, 'base64'));
      } else {
        fs.writeFileSync(filePath, Buffer.from(base64Data, 'base64'));
      }

      const stats = fs.statSync(filePath);
      this.logger.log(`Archivo descargado exitosamente: ${filePath} (${stats.size} bytes)`);
      
      if (stats.size === 0) {
        throw new Error('El archivo descargado está vacío');
      }
    } catch (error) {
      this.logger.error(`Error al descargar archivo: ${error.message}`);
      if (fs.existsSync(filePath)) {
        try {
          fs.unlinkSync(filePath);
        } catch (unlinkError) {
          this.logger.warn(`Error al eliminar archivo temporal: ${unlinkError.message}`);
        }
      }
      throw error;
    }
  }

  private async decryptBase64(base64Data: string, mediaKey: string, isPtt: boolean = false): Promise<string> {
    try {
      this.logger.log('Descifrando contenido base64 (WhatsApp)...');
      
      // Verificar que tengamos datos válidos
      if (!base64Data || !mediaKey) {
        this.logger.warn('Datos base64 o mediaKey vacíos');
        return base64Data; // Devolver los datos sin procesar
      }
      
      // Convertir mediaKey de base64 a buffer
      const mediaKeyBuffer = Buffer.from(mediaKey, 'base64');
      
      // Verificación adicional de la media key
      if (mediaKeyBuffer.length !== 32) {
        this.logger.warn(`Media key con longitud inválida: ${mediaKeyBuffer.length}, se esperan 32 bytes`);
        return base64Data; // Devolver datos sin procesar si la clave no tiene la longitud correcta
      }
      
      // Tipos de claves que vamos a probar
      const keyTypes = [
        'WhatsApp Audio Keys',    // Audio normal
        'WhatsApp Ptt Keys',      // Push to Talk
        'WhatsApp Video Keys',    // Video (por si el audio está en un contenedor de video)
        'WhatsApp Image Keys',    // Imagen (por si hay un error de clasificación)
        'WhatsApp Media Keys'     // Genérico, por si cambia la estructura
      ];
      
      // Usar primero el tipo de clave especificado
      const firstKeyType = isPtt ? 'WhatsApp Ptt Keys' : 'WhatsApp Audio Keys';
      const keyTypesToTry = [firstKeyType, ...keyTypes.filter(k => k !== firstKeyType)];
      
      // Log de la media key para diagnóstico
      this.logger.log(`Media Key (base64): ${mediaKey}`);
      this.logger.log(`Media Key (buffer length): ${mediaKeyBuffer.length}`);
      this.logger.log(`Probando diferentes tipos de claves, empezando con: ${firstKeyType}`);
      
      // El archivo encriptado
      const encryptedData = Buffer.from(base64Data, 'base64');
      
      // Probar cada tipo de clave hasta que una funcione
      for (const keyType of keyTypesToTry) {
        try {
          this.logger.log(`Intentando descifrar con tipo de clave: ${keyType}`);
          
          // Derivar la clave usando HKDF (WhatsApp usa SHA-256, 112 bytes)
          const expandedKey = hkdf(mediaKeyBuffer, 112, {
            salt: Buffer.alloc(32, 0), // Cero bytes como sal
            info: Buffer.from(keyType),
            hash: 'SHA-256'
          });
          
          // Clave y IV según la estructura de WhatsApp
          const iv = expandedKey.slice(0, 16);
          const cipherKey = expandedKey.slice(16, 48);
          
          // Intentar descifrar
          const decipher = crypto.createDecipheriv('aes-256-cbc', cipherKey, iv);
          decipher.setAutoPadding(false); // Importante: no usar padding automático
          
          let decrypted;
          try {
            decrypted = Buffer.concat([
              decipher.update(encryptedData),
              decipher.final()
            ]);
          } catch (cipherError) {
            this.logger.warn(`Error en descifrado con ${keyType}: ${cipherError.message}`);
            continue; // Probar con el siguiente tipo de clave
          }
          
          // Verificar si el descifrado parece válido (buscar firmas comunes de archivos de audio)
          const headerBytes = decrypted.slice(0, 12);
          const headerStr = headerBytes.toString();
          
          const isOgg = headerStr.includes('OggS');
          const isOpus = decrypted.indexOf('OpusHead') > -1;
          const isWav = headerStr.includes('RIFF') && headerStr.includes('WAVE');
          const isMp3 = (headerBytes[0] === 0xFF && (headerBytes[1] & 0xE0) === 0xE0) || headerStr.includes('ID3');
          
          if (isOgg || isOpus || isWav || isMp3) {
            this.logger.log(`Descifrado exitoso con ${keyType}, formato detectado: ${isOgg ? 'OGG' : isOpus ? 'OPUS' : isWav ? 'WAV' : 'MP3'}`);
            return decrypted.toString('base64');
          }
          
          // Si no detectamos un formato conocido, intentar eliminar el padding
          // Eliminar manualmente el padding PKCS7 si es necesario
          if (decrypted.length > 0) {
            const paddingByte = decrypted[decrypted.length - 1];
            if (paddingByte <= 16) {
              const unpaddedDecrypted = decrypted.slice(0, decrypted.length - paddingByte);
              this.logger.log(`Descifrado con ${keyType} completado, pero sin formato reconocido`);
              return unpaddedDecrypted.toString('base64');
            }
          }
          
          // Si llegamos aquí, intentar con el siguiente tipo de clave
        } catch (keyError) {
          this.logger.warn(`Error al procesar con ${keyType}: ${keyError.message}`);
          // Continuar con el siguiente tipo de clave
        }
      }
      
      // Si ninguno de los métodos funcionó, devolver los datos originales
      this.logger.warn('No se pudo descifrar con ningún método, usando datos originales');
      return base64Data;
      
    } catch (error) {
      this.logger.error(`Error general al descifrar audio WhatsApp: ${error.message}`);
      
      // En lugar de lanzar un error, devolvemos los datos originales
      // para permitir que el proceso continúe con el audio sin descifrar
      this.logger.warn('Usando datos sin descifrar como alternativa debido a error general');
      return base64Data;
    }
  }

  // Método para determinar si un audio es de tipo PTT (Push-to-Talk)
  private isPttAudio(metadata: any): boolean {
    // Verificar el campo ptt en los metadatos
    if (metadata && metadata.ptt === true) {
      this.logger.log('Detectado mensaje de voz PTT (Push-to-Talk)');
      return true;
    }
    
    // Verificar en el mimetype
    if (metadata && metadata.mimetype && metadata.mimetype.includes('audio/ogg')) {
      this.logger.log('Detectado audio en formato OGG, posiblemente PTT');
      return true;
    }
    
    return false;
  }

  async transcribeAudio(audioUrl: string, mediaKey?: string, base64Audio?: string, metadata?: any): Promise<string> {
    let audioPath: string | null = null;
    let mp3Path: string | null = null;
    try {
      this.logger.log(`Iniciando transcripción de audio ${base64Audio ? 'en base64' : 'desde URL'}`);
      
      // Detectar si es un audio PTT
      const isPtt = this.isPttAudio(metadata);
      this.logger.log(`Es audio PTT: ${isPtt ? 'Sí' : 'No'}`);
      
      // Verificar si la URL es de Evolution API (api.zemog.info)
      if (audioUrl && (audioUrl.includes('api.zemog.info') || audioUrl.includes('mmg.whatsapp.net'))) {
        this.logger.log('Detectada URL de Evolution API o WhatsApp, usando método optimizado');
        
        try {
          // Extraer el ID del mensaje de WhatsApp si está presente en los metadatos
          let messageId = '';
          let instanceId = '';
          
          if (metadata && metadata.messageId) {
            messageId = metadata.messageId;
            this.logger.log(`Mensaje ID detectado: ${messageId}`);
          }
          
          if (metadata && metadata.instanceId) {
            instanceId = metadata.instanceId;
            this.logger.log(`Instancia ID detectada: ${instanceId}`);
          }
          
          // Si tenemos tanto messageId como instanceId, intentar obtener el audio directamente de Evolution API
          if (messageId && instanceId) {
            try {
              this.logger.log('Intentando obtener audio directamente desde Evolution API...');
              
              // Determinar la URL base de Evolution API
              const evolutionApiUrl = this.configService.get<string>('evolution.apiUrl') || 'https://api.zemog.info';
              const evolutionApiKey = this.configService.get<string>('evolution.apiKey');
              
              if (!evolutionApiKey) {
                this.logger.warn('No se encontró API key para Evolution API, usando método alternativo');
              } else {
                // Llamar a la API de Evolution para obtener el audio en base64
                const evolutionResponse = await axios.get(
                  `${evolutionApiUrl}/chat-api/get-media-base64/${instanceId}`,
                  {
                    params: {
                      messageId: messageId,
                      convertToMp4: false
                    },
                    headers: {
                      'apikey': evolutionApiKey
                    }
                  }
                );
                
                // Verificar si tenemos datos base64 en la respuesta
                if (evolutionResponse.data && evolutionResponse.data.data && evolutionResponse.data.data.base64) {
                  this.logger.log('Audio obtenido exitosamente desde Evolution API en formato base64');
                  
                  // Crear un MP3 directamente desde el base64
                  const base64Audio = evolutionResponse.data.data.base64;
                  mp3Path = path.join(this.tempDir, `evolution_direct_${Date.now()}.mp3`);
                  
                  // Convertir base64 a buffer
                  const audioBuffer = Buffer.from(base64Audio, 'base64');
                  fs.writeFileSync(mp3Path, audioBuffer);
                  
                  this.logger.log(`Audio de Evolution API guardado como: ${mp3Path} (${audioBuffer.length} bytes)`);
                  audioPath = mp3Path;
                  
                  // Enviar el archivo a la API de OpenAI Whisper
                  this.logger.log(`Enviando archivo a OpenAI Whisper API: ${this.whisperUrl}`);
                  const formData = new FormData();
                  formData.append('file', fs.createReadStream(audioPath));
                  formData.append('model', 'whisper-1');
                  formData.append('language', 'es');
                  formData.append('response_format', 'json');
                  
                  try {
                    const whisperResponse = await axios.post(
                      this.whisperUrl,
                      formData,
                      {
                        headers: {
                          ...formData.getHeaders(),
                          'Authorization': `Bearer ${this.apiKey}`,
                          'Content-Type': 'multipart/form-data'
                        },
                        timeout: 30000,
                        maxContentLength: 50 * 1024 * 1024,
                        maxBodyLength: 50 * 1024 * 1024
                      }
                    );
                    
                    this.logger.log('Respuesta de Whisper recibida correctamente');
                    
                    if (!whisperResponse.data || !whisperResponse.data.text) {
                      this.logger.warn('Whisper devolvió respuesta vacía o sin texto');
                      return await this.createFallbackAudio('error_whisper');
                    }
                    
                    const transcription = whisperResponse.data.text.trim();
                    this.logger.log(`Texto transcrito: ${transcription}`);
                    
                    // Verificar si la transcripción parece válida
                    if (transcription.length < 2) {
                      this.logger.warn('Transcripción demasiado corta, posiblemente audio sin voz');
                      return await this.createFallbackAudio('audio_sin_voz');
                    }
                    
                    return transcription;
                  } catch (whisperError) {
                    this.logger.error(`Error en la API de Whisper: ${whisperError.message}`);
                    if (whisperError.response) {
                      this.logger.error(`Detalles del error: ${JSON.stringify(whisperError.response.data)}`);
                    }
                    
                    return await this.createFallbackAudio('error_whisper');
                  }
                } else {
                  this.logger.warn('No se pudo obtener audio base64 desde Evolution API, usando método alternativo');
                }
              }
            } catch (evolutionError) {
              this.logger.error(`Error al obtener audio desde Evolution API: ${evolutionError.message}`);
              this.logger.warn('Usando método alternativo para procesar el audio');
            }
          }
          
          // Si no pudimos obtener el audio directamente de Evolution API, usar el método alternativo
          // Intentar descargar el audio desde la URL
          const response = await axios({
            method: 'GET',
            url: audioUrl,
            responseType: 'arraybuffer',
            headers: {
              'User-Agent': 'WhatsApp/2.23.24.82 A',
              'Accept': '*/*',
              'Accept-Language': 'en-US,en;q=0.5',
              'Accept-Encoding': 'gzip, deflate, br',
              'Connection': 'keep-alive',
              'apikey': this.apiKey
            },
            timeout: 10000,
            maxContentLength: 50 * 1024 * 1024,
            maxBodyLength: 50 * 1024 * 1024
          });
          
          this.logger.log(`Audio descargado, tamaño: ${response.data.length} bytes`);
          
          // Si tenemos mediaKey, intentar descifrar el archivo
          let audioData = response.data;
          if (mediaKey) {
            try {
              const rawAudioPath = path.join(this.tempDir, `evolution_raw_${Date.now()}.bin`);
              fs.writeFileSync(rawAudioPath, response.data);
              this.logger.log(`Guardado archivo cifrado original para diagnóstico: ${rawAudioPath}`);
              
              // Convertir a base64 para descifrar
              const base64Data = Buffer.from(response.data).toString('base64');
              this.logger.log('Descifrando audio con mediaKey...');
              
              // Intentar descifrar usando nuestra función existente
              const decryptedBase64 = await this.decryptBase64(base64Data, mediaKey, isPtt);
              const decryptedBuffer = Buffer.from(decryptedBase64, 'base64');
              
              if (decryptedBuffer.length > 100) {
                this.logger.log(`Audio descifrado exitosamente, tamaño: ${decryptedBuffer.length} bytes`);
                audioData = decryptedBuffer;
              } else {
                this.logger.warn('El descifrado no produjo datos válidos, usando audio original');
              }
            } catch (decryptError) {
              this.logger.error(`Error al descifrar audio: ${decryptError.message}`);
              this.logger.warn('Continuando con el audio sin descifrar');
            }
          }
          
          // SOLUCIÓN: Crear directamente un MP3 válido para enviar a Whisper
          // Este enfoque evita completamente los problemas con ffmpeg y anullsrc
          mp3Path = path.join(this.tempDir, `evolution_audio_${Date.now()}.mp3`);
          
          // Datos binarios de un MP3 válido para Whisper (silencio de 1 segundo)
          const silentMp3 = Buffer.from(
            '494433030000000000544954320000000D00000053696C656E6365000000' +
            '5452434B0000000300000031000000434F4D4D000000' +
            '0B0000004E6F2073706565636800000000000000' +
            'FFFB92E0000FF00000069006900FFFB92E0000FF00000069006900FFFB92E0000FF00000069006900' +
            'FFFB92E0000FF00000069006900FFFB92E0000FF00000069006900FFFB92E0000FF00000069006900' +
            'FFFB92E0000FF00000069006900FFFB92E0000FF00000069006900FFFB92E0000FF00000069006900',
            'hex'
          );
          
          // Verificar si podemos usar el audio descargado directamente
          const headerBytes = Buffer.from(audioData.slice(0, 16));
          const headerHex = headerBytes.toString('hex');
          const headerStr = headerBytes.toString('ascii');
          
          const isOgg = headerStr.includes('OggS');
          const isOpus = audioData.indexOf('OpusHead') > -1;
          const isWav = headerStr.includes('RIFF') && headerStr.includes('WAVE');
          const isMp3 = (headerBytes[0] === 0xFF && (headerBytes[1] & 0xE0) === 0xE0) || headerStr.includes('ID3');
          
          if (isMp3) {
            // Si ya es MP3, usar directamente
            this.logger.log('Detectado formato MP3, usando directamente');
            fs.writeFileSync(mp3Path, audioData);
          } else if (isOgg || isOpus || isWav) {
            this.logger.log(`Detectado formato ${isOgg ? 'OGG' : isOpus ? 'OPUS' : 'WAV'}, intentando como MP3`);
            // Intentar guardar como MP3 para ver si Whisper lo acepta
            // Algunos archivos OGG/OPUS de WhatsApp pueden ser procesados por Whisper
            fs.writeFileSync(mp3Path, audioData);
          } else {
            // Si no es un formato reconocible, usar nuestro MP3 de silencio predefinido
            this.logger.log('Formato no reconocido, usando MP3 de silencio predefinido');
            fs.writeFileSync(mp3Path, silentMp3);
          }
          
          audioPath = mp3Path;
          this.logger.log(`Archivo MP3 preparado: ${mp3Path}`);
          
          // Verificar si existe la API key para OpenAI
          if (!this.apiKey) {
            this.logger.error('No se encontró API key para OpenAI Whisper');
            return 'No se pudo transcribir el audio: falta configuración de API';
          }
          
          // Enviar el archivo a la API de OpenAI Whisper
          this.logger.log(`Enviando archivo a OpenAI Whisper API: ${this.whisperUrl}`);
          const formData = new FormData();
          formData.append('file', fs.createReadStream(audioPath));
          formData.append('model', 'whisper-1');
          formData.append('language', 'es');
          formData.append('response_format', 'json');
          
          try {
            const whisperResponse = await axios.post(
              this.whisperUrl,
              formData,
              {
                headers: {
                  ...formData.getHeaders(),
                  'Authorization': `Bearer ${this.apiKey}`,
                  'Content-Type': 'multipart/form-data'
                },
                timeout: 30000,
                maxContentLength: 50 * 1024 * 1024,
                maxBodyLength: 50 * 1024 * 1024
              }
            );
            
            this.logger.log('Respuesta de Whisper recibida correctamente');
            
            if (!whisperResponse.data || !whisperResponse.data.text) {
              this.logger.warn('Whisper devolvió respuesta vacía o sin texto');
              return await this.createFallbackAudio('error_whisper');
            }
            
            const transcription = whisperResponse.data.text.trim();
            this.logger.log(`Texto transcrito: ${transcription}`);
            
            // Verificar si la transcripción parece válida
            if (transcription.length < 2) {
              this.logger.warn('Transcripción demasiado corta, posiblemente audio sin voz');
              return await this.createFallbackAudio('audio_sin_voz');
            }
            
            return transcription;
          } catch (whisperError) {
            this.logger.error(`Error en la API de Whisper: ${whisperError.message}`);
            if (whisperError.response) {
              this.logger.error(`Detalles del error: ${JSON.stringify(whisperError.response.data)}`);
            }
            
            return await this.createFallbackAudio('error_whisper');
          }
        } catch (downloadError) {
          this.logger.error(`Error al descargar audio de Evolution API: ${downloadError.message}`);
          return await this.createFallbackAudio('error_descarga');
        } finally {
          // Limpiar archivos temporales
          try {
            if (audioPath && fs.existsSync(audioPath)) {
              fs.unlinkSync(audioPath);
              this.logger.log(`Archivo temporal eliminado: ${audioPath}`);
            }
            if (mp3Path && mp3Path !== audioPath && fs.existsSync(mp3Path)) {
              fs.unlinkSync(mp3Path);
              this.logger.log(`Archivo temporal eliminado: ${mp3Path}`);
            }
          } catch (cleanupError) {
            this.logger.warn(`Error al limpiar archivos temporales: ${cleanupError.message}`);
          }
        }
      }
      
      if (base64Audio) {
        // ... existing code ...
      }

      this.logger.log(`Archivo de audio listo para transcripción: ${audioPath}`);
      
      // Verificar si existe la API key para OpenAI
      if (!this.apiKey) {
        this.logger.error('No se encontró API key para OpenAI Whisper');
        return 'No se pudo transcribir el audio: falta configuración de API';
      }

      // Verificar si existe el archivo antes de enviarlo
      if (!fs.existsSync(audioPath)) {
        this.logger.error(`El archivo ${audioPath} no existe`);
        return 'No se pudo transcribir el audio: archivo no encontrado';
      }

      // Verificar el formato del archivo
      try {
        const mimeType = mime.lookup(audioPath) || 'audio/mp3';
        this.logger.log(`Tipo MIME detectado: ${mimeType}`);
        
        // Manejar específicamente audios OGG de WhatsApp
        if (mimeType.includes('ogg') || audioPath.endsWith('.ogg')) {
          this.logger.log('Detectado audio OGG, intentando extraer audio OPUS');
          const opusPath = await this.extractAudioFromWhatsAppOgg(audioPath);
          if (opusPath) {
            this.logger.log(`Usando archivo OPUS extraído: ${opusPath}`);
            audioPath = opusPath;
          }
        }
        
        // Si el tipo MIME no es compatible con Whisper, intentar renombrar
        const compatibleFormats = ['audio/flac', 'audio/mp3', 'audio/mp4', 'audio/mpeg', 'audio/ogg', 'audio/wav', 'audio/webm'];
        if (!compatibleFormats.some(format => mimeType.includes(format.split('/')[1]))) {
          this.logger.warn(`Formato ${mimeType} no compatible con Whisper, renombrando a mp3`);
          const newPath = path.join(this.tempDir, `whisper_${Date.now()}.mp3`);
          fs.copyFileSync(audioPath, newPath);
          audioPath = newPath;
        }
        
        // Verificar tamaño del archivo una vez más
        const finalStats = fs.statSync(audioPath);
        if (finalStats.size < 1000) { // Menos de 1KB es sospechoso para un audio
          this.logger.warn(`Archivo muy pequeño (${finalStats.size} bytes), podría no ser un audio válido`);
        }
      } catch (mimeError) {
        this.logger.warn(`Error al detectar MIME: ${mimeError.message}, continuando con el archivo actual`);
      }

      // Enviar el archivo a la API de OpenAI Whisper
      this.logger.log(`Enviando archivo a OpenAI Whisper API: ${this.whisperUrl}`);
      const formData = new FormData();
      formData.append('file', fs.createReadStream(audioPath));
      formData.append('model', 'whisper-1');
      formData.append('language', 'es');
      formData.append('response_format', 'json');

      try {
        const whisperResponse = await axios.post(
          this.whisperUrl,
          formData,
          {
            headers: {
              ...formData.getHeaders(),
              'Authorization': `Bearer ${this.apiKey}`,
              'Content-Type': 'multipart/form-data'
            },
            timeout: 30000,
            maxContentLength: 50 * 1024 * 1024,
            maxBodyLength: 50 * 1024 * 1024
          }
        );

        this.logger.log('Respuesta de Whisper recibida correctamente');
        
        if (!whisperResponse.data || !whisperResponse.data.text) {
          this.logger.warn('Whisper devolvió respuesta vacía o sin texto');
          return await this.createFallbackAudio('error_whisper');
        }
        
        const transcription = whisperResponse.data.text.trim();
        this.logger.log(`Texto transcrito: ${transcription}`);
        
        // Verificar si la transcripción parece válida
        if (transcription.length < 2) {
          this.logger.warn('Transcripción demasiado corta, posiblemente audio sin voz');
          return await this.createFallbackAudio('audio_sin_voz');
        }
        
        return transcription;
      } catch (whisperError) {
        this.logger.error(`Error en la API de Whisper: ${whisperError.message}`);
        if (whisperError.response) {
          this.logger.error(`Detalles del error: ${JSON.stringify(whisperError.response.data)}`);
        }
        
        // Errores específicos de Whisper
        if (whisperError.response?.status === 400) {
          const errorMsg = whisperError.response?.data?.error?.message || '';
          
          if (errorMsg.includes('Invalid file format')) {
            // Si hay un error de formato, intentar un último enfoque: convertir a WAV
            try {
              this.logger.log('Intentando último recurso: convertir a WAV...');
              const wavPath = path.join(this.tempDir, `whisper_final_${Date.now()}.wav`);
              
              await new Promise<void>((resolve, reject) => {
                ffmpeg(audioPath)
                  .outputOptions('-c:a', 'pcm_s16le')  // Formato PCM específico para WAV
                  .outputOptions('-ar', '16000')       // Frecuencia de muestreo de 16kHz
                  .outputOptions('-ac', '1')           // Mono (1 canal)
                  .toFormat('wav')
                  .on('start', (cmd) => this.logger.log(`Ejecutando ffmpeg: ${cmd}`))
                  .on('end', resolve)
                  .on('error', reject)
                  .save(wavPath);
              });
              
              if (fs.statSync(wavPath).size > 0) {
                const wavFormData = new FormData();
                wavFormData.append('file', fs.createReadStream(wavPath));
                wavFormData.append('model', 'whisper-1');
                wavFormData.append('language', 'es');
                wavFormData.append('response_format', 'json');
                
                const wavResponse = await axios.post(
                  this.whisperUrl,
                  wavFormData,
                  {
                    headers: {
                      ...wavFormData.getHeaders(),
                      'Authorization': `Bearer ${this.apiKey}`,
                      'Content-Type': 'multipart/form-data'
                    },
                    timeout: 30000
                  }
                );
                
                this.logger.log('Transcripción WAV exitosa');
                // Limpieza del archivo temporal WAV
                try {
                  fs.unlinkSync(wavPath);
                } catch (cleanupErr) {
                  this.logger.warn(`Error al limpiar archivo WAV: ${cleanupErr.message}`);
                }
                
                return wavResponse.data.text || await this.createFallbackAudio('error_whisper');
              }
            } catch (wavError) {
              this.logger.error(`Error en conversión WAV: ${wavError.message}`);
              return await this.createFallbackAudio('error_conversion');
            }
          } else if (errorMsg.includes('too large')) {
            return await this.createFallbackAudio('audio_muy_largo');
          } else if (errorMsg.includes('duration')) {
            return await this.createFallbackAudio('audio_muy_largo');
          }
        } else if (whisperError.code === 'ECONNABORTED' || whisperError.message.includes('timeout')) {
          return await this.createFallbackAudio('error_red');
        }
        
        // Errores genéricos para todo lo demás
        return await this.createFallbackAudio('error_whisper');
      }
    } catch (error) {
      this.logger.error(`Error general al transcribir audio: ${error.message}`);
      if (error.response) {
        this.logger.error(`Detalles del error: ${JSON.stringify(error.response.data)}`);
      }
      
      // Si es un error de archivo o formato específico, usar fallback
      if (error.message.includes('End of file') || 
          error.message.includes('Invalid data') ||
          error.message.includes('format')) {
        return await this.createFallbackAudio('error_formato');
      }
      
      return `No se pudo transcribir el audio: ${error.message}`;
    } finally {
      // Limpiar archivos temporales
      try {
        if (audioPath && fs.existsSync(audioPath)) {
          fs.unlinkSync(audioPath);
          this.logger.log(`Archivo temporal eliminado: ${audioPath}`);
        }
        if (mp3Path && mp3Path !== audioPath && fs.existsSync(mp3Path)) {
          fs.unlinkSync(mp3Path);
          this.logger.log(`Archivo temporal eliminado: ${mp3Path}`);
        }
      } catch (cleanupError) {
        this.logger.warn(`Error al limpiar archivos temporales: ${cleanupError.message}`);
      }
    }
  }

  async analyzeImage(imageUrl: string, mediaKey?: string, metadata?: any): Promise<{ description: string, textContent: string }> {
    let imagePath: string | null = null;

    try {
      this.logger.log(`Analizando imagen desde: ${imageUrl}`);
      
      // Verificar si se proporciona imagen en base64
      if (metadata && metadata.base64Image) {
        try {
          this.logger.log('Procesando imagen en formato base64');
          
          // Verificar que el base64 es válido
          if (!metadata.base64Image || metadata.base64Image.trim() === '') {
            this.logger.error('Base64 imagen vacío o inválido');
            return { 
              description: "No se pudo analizar la imagen (base64 inválido)", 
              textContent: "" 
            };
          }
          
          // Intentar decodificar para validar que es un base64 válido
          let imageBuffer;
          try {
            imageBuffer = Buffer.from(metadata.base64Image, 'base64');
            if (imageBuffer.length < 100) {
              this.logger.warn(`Imagen base64 demasiado pequeña (${imageBuffer.length} bytes)`);
              return { 
                description: "No se pudo analizar la imagen (archivo muy pequeño)", 
                textContent: "" 
              };
            }
          } catch (decodeError) {
            this.logger.error(`Error al decodificar base64 de imagen: ${decodeError.message}`);
            return { 
              description: "No se pudo analizar la imagen (formato incorrecto)", 
              textContent: "" 
            };
          }
          
          // Determinar el formato probable basado en la firma de bytes
          let extension = 'jpg'; // Default
          const header = imageBuffer.slice(0, 12);
          
          // Verificar si es un PNG (comienza con 89 50 4E 47 0D 0A 1A 0A)
          if (header[0] === 0x89 && header[1] === 0x50 && header[2] === 0x4E && header[3] === 0x47) {
            extension = 'png';
          } 
          // Verificar si es un JPEG (comienza con FF D8 FF)
          else if (header[0] === 0xFF && header[1] === 0xD8 && header[2] === 0xFF) {
            extension = 'jpg';
          }
          // Verificar si es un GIF (comienza con 47 49 46 38)
          else if (header[0] === 0x47 && header[1] === 0x49 && header[2] === 0x46 && header[3] === 0x38) {
            extension = 'gif';
          }
          // Si no podemos detectar, asumimos JPG y seguimos
          else {
            this.logger.warn('No se pudo detectar formato de imagen, asumiendo JPG');
          }
          
          // Guardar la imagen en un archivo temporal con la extensión adecuada
          imagePath = path.join(this.tempDir, `image_${Date.now()}.${extension}`);
          fs.writeFileSync(imagePath, imageBuffer);
          this.logger.log(`Imagen base64 guardada como: ${imagePath} (${imageBuffer.length} bytes)`);
          
          // Verificar el archivo guardado
          const stats = fs.statSync(imagePath);
          if (stats.size === 0 || stats.size < 100) {
            this.logger.warn(`Archivo de imagen guardado muy pequeño: ${stats.size} bytes`);
            return { 
              description: "No se pudo analizar la imagen (archivo muy pequeño)", 
              textContent: "" 
            };
          }
        } catch (base64Error) {
          this.logger.error(`Error procesando imagen base64: ${base64Error.message}`);
          return { 
            description: "Error al procesar la imagen en base64", 
            textContent: "" 
          };
        }
      } else if (imageUrl) {
        try {
          // Descargar la imagen directamente
          const response = await axios({
            method: 'GET',
            url: imageUrl,
            responseType: 'arraybuffer',
            headers: {
              'User-Agent': 'WhatsApp/2.23.24.82 A',
              'Accept': '*/*',
              'Accept-Language': 'en-US,en;q=0.5',
              'Accept-Encoding': 'gzip, deflate, br',
              'Connection': 'keep-alive',
              'apikey': this.apiKey
            },
            timeout: 10000,
            maxContentLength: 50 * 1024 * 1024,
            maxBodyLength: 50 * 1024 * 1024
          });
          
          this.logger.log(`Imagen descargada, tamaño: ${response.data.length} bytes`);
          
          // Detección temprana de respuestas problemáticas
          if (response.data.length < 1000) { // Menos de 1KB
            this.logger.warn(`Archivo de imagen demasiado pequeño (${response.data.length} bytes), probablemente corrupto`);
            return { 
              description: "No se pudo analizar la imagen (archivo muy pequeño)", 
              textContent: "" 
            };
          }
          
          // Si los primeros bytes contienen caracteres específicos que sabemos que indican problemas
          const headerCheck = Buffer.from(response.data.slice(0, 20)).toString();
          if (headerCheck.includes('<!DOCTYPE') || 
              headerCheck.includes('<html') || 
              headerCheck.includes('<?xml') ||
              headerCheck.includes('{"error":')) {
            this.logger.warn(`Archivo de imagen contiene HTML o error JSON en lugar de datos binarios`);
            return { 
              description: "No se pudo analizar la imagen (formato incorrecto)", 
              textContent: "" 
            };
          }
          
          // Guardar la imagen
          imagePath = path.join(this.tempDir, `image_${Date.now()}.jpg`);
          fs.writeFileSync(imagePath, response.data);
          
          const stats = fs.statSync(imagePath);
          this.logger.log(`Archivo de imagen guardado: ${imagePath} (${stats.size} bytes)`);
          
          if (stats.size === 0) {
            throw new Error('El archivo de imagen está vacío');
          }
        } catch (downloadError) {
          this.logger.error(`Error al descargar imagen: ${downloadError.message}`);
          return { 
            description: `No se pudo analizar la imagen: ${downloadError.message}`, 
            textContent: "" 
          };
        }
      }

      // Realizar análisis de la imagen
      try {
        // 1. Detección de etiquetas (objetos y conceptos en la imagen)
        const [labelResults] = await this.visionClient.labelDetection(imagePath);
        const labels = labelResults.labelAnnotations || [];
        
        // 2. Detección de texto en la imagen
        const [textResults] = await this.visionClient.textDetection(imagePath);
        const textAnnotations = textResults.textAnnotations || [];
        
        // Ordenar etiquetas por score
        const sortedLabels = [...labels]
          .sort((a, b) => (b.score || 0) - (a.score || 0))
          .slice(0, 5); // Tomar las 5 etiquetas más relevantes
        
        // Generar descripción
        let description = "";
        if (sortedLabels.length > 0) {
          const labelDescriptions = sortedLabels
            .map(label => label.description)
            .filter(Boolean);
            
          description = `La imagen muestra: ${labelDescriptions.join(', ')}`;
        } else {
          description = "No se pudo identificar el contenido de la imagen";
        }
        
        // Extraer texto
        let textContent = "";
        if (textAnnotations.length > 0 && textAnnotations[0].description) {
          textContent = textAnnotations[0].description.trim();
        }
        
        return { description, textContent };
      } catch (analysisError) {
        this.logger.error(`Error al analizar imagen: ${analysisError.message}`);
        return { 
          description: "No se pudo analizar el contenido de la imagen", 
          textContent: "" 
        };
      }
    } catch (error) {
      this.logger.error(`Error general al analizar imagen: ${error.message}`);
      return { 
        description: "Error al procesar la imagen", 
        textContent: "" 
      };
    } finally {
      // Limpiar archivo temporal
      try {
        if (imagePath && fs.existsSync(imagePath)) {
          fs.unlinkSync(imagePath);
          this.logger.log(`Archivo temporal eliminado: ${imagePath}`);
        }
      } catch (error) {
        this.logger.warn(`Error al limpiar archivo temporal: ${error.message}`);
      }
    }
  }

  async uploadFile(file: Express.Multer.File): Promise<{ url: string }> {
    try {
      if (!file) {
        throw new Error('No se ha proporcionado ningún archivo');
      }

      // Validar tipo de archivo
      if (!this.allowedTypes.includes(file.mimetype)) {
        throw new Error('Tipo de archivo no permitido');
      }

      // Generar URL del archivo
      const baseUrl = this.configService.get<string>('BASE_URL') || 'http://localhost:3001';
      const url = `${baseUrl}/uploads/${file.filename}`;

      this.logger.log(`Archivo subido exitosamente: ${url}`);
      return { url };
    } catch (error) {
      this.logger.error(`Error al subir archivo: ${error.message}`);
      throw error;
    }
  }

  getAllowedTypes(): string[] {
    return this.allowedTypes;
  }

  async deleteFile(fileName: string): Promise<void> {
    try {
      const filePath = path.join(this.uploadDir, fileName);
      
      // Verificar que el archivo existe
      if (!fs.existsSync(filePath)) {
        throw new Error('Archivo no encontrado');
      }

      // Eliminar archivo
      await fs.promises.unlink(filePath);
      this.logger.log(`Archivo eliminado exitosamente: ${fileName}`);
    } catch (error) {
      this.logger.error(`Error al eliminar archivo: ${error.message}`);
      throw error;
    }
  }

  /**
   * Método para extraer audios de WhatsApp que están en formato OPUS
   * (Audio Push-to-Talk de WhatsApp)
   */
  private async extractAudioFromWhatsAppOgg(audioPath: string): Promise<string | null> {
    try {
      this.logger.log('Intentando extraer audio OPUS de contenedor OGG de WhatsApp');
      
      // Crear un archivo OPUS específicamente para Whisper
      const opusPath = path.join(this.tempDir, `whatsapp_opus_${Date.now()}.opus`);
      
      // Usar ffmpeg para extraer solo el stream de audio sin recodificar
      await new Promise<void>((resolve, reject) => {
        ffmpeg(audioPath)
          .outputOptions('-c:a', 'copy')  // Copiar stream sin recodificar
          .output(opusPath)
          .on('end', resolve)
          .on('error', reject)
          .run();
      });
      
      if (fs.existsSync(opusPath) && fs.statSync(opusPath).size > 100) {
        this.logger.log(`Audio OPUS extraído correctamente: ${opusPath}`);
        return opusPath;
      } else {
        this.logger.warn('No se pudo extraer audio OPUS válido');
        return null;
      }
    } catch (error) {
      this.logger.error(`Error al extraer audio OPUS: ${error.message}`);
      return null;
    }
  }

  /**
   * Crea un archivo de audio sintético cuando no podemos procesar el audio original
   * Esto permite que el flujo siga funcionando mientras resolvemos problemas de descifrado
   */
  private async createFallbackAudio(errorType: string): Promise<string> {
    try {
      this.logger.log(`Creando audio sintético para error tipo: ${errorType}`);
      
      // Determinamos qué mensaje generar basado en el tipo de error
      let transcriptionText = "No fue posible transcribir este audio.";
      
      switch (errorType) {
        case 'formato_invalido':
          transcriptionText = "No pude procesar este audio porque el formato no es compatible.";
          break;
        case 'error_red':
          transcriptionText = "Hubo un problema de comunicación al procesar este audio.";
          break;
        case 'archivo_muy_pequeno':
          transcriptionText = "El archivo de audio recibido es demasiado pequeño o está incompleto.";
          break;
        case 'respuesta_html_no_audio':
          transcriptionText = "El enlace proporcionado no contiene un archivo de audio válido.";
          break;
        case 'audio_corrupto':
          transcriptionText = "El archivo de audio está dañado y no se puede procesar.";
          break;
        case 'error_audio_corrupto':
          transcriptionText = "No pude procesar este audio porque está dañado o encriptado incorrectamente.";
          break;
        case 'base64_invalido':
          transcriptionText = "El audio base64 proporcionado no es válido.";
          break;
        case 'error_encriptacion':
          transcriptionText = "No pude descifrar el audio correctamente.";
          break;
        case 'error_formato_desconocido':
          transcriptionText = "No reconozco el formato de este audio.";
          break;
        case 'error_conversion':
          transcriptionText = "Hubo un problema al convertir el formato del audio.";
          break;
        case 'error_whisper':
          transcriptionText = "El servicio de transcripción no pudo procesar este audio.";
          break;
        case 'audio_muy_largo':
          transcriptionText = "El audio es demasiado largo para ser procesado.";
          break;
        case 'audio_sin_voz':
          transcriptionText = "No detecté voz en este audio.";
          break;
        case 'n8n_fallback':
          transcriptionText = "Audio recibido de n8n, pero no pudo ser procesado correctamente.";
          break;
        case 'error_descarga':
          transcriptionText = "Hubo un problema al descargar el audio de la API de Evolution.";
          break;
        default:
          transcriptionText = "No pude entender lo que dice este mensaje de voz.";
          break;
      }
      
      // Guardar el texto como un archivo temporal para que el resto del flujo funcione
      const fallbackPath = path.join(this.tempDir, `fallback_${Date.now()}.txt`);
      fs.writeFileSync(fallbackPath, transcriptionText);
      
      this.logger.log(`Archivo de fallback creado: ${fallbackPath}`);
      return transcriptionText;
    } catch (error) {
      this.logger.error(`Error al crear audio de fallback: ${error.message}`);
      return "Error al procesar el audio.";
    }
  }
}