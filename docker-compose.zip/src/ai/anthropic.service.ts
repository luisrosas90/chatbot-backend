import { Injectable } from '@nestjs/common';

@Injectable()
export class AnthropicService {
  // Implementación básica del servicio Anthropic
} 