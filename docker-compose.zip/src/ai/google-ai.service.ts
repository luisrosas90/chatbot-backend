import { Injectable } from '@nestjs/common';

@Injectable()
export class GoogleAIService {
  // Implementación básica del servicio Google AI
} 