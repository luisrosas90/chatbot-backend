import { Injectable } from '@nestjs/common';

@Injectable()
export class OllamaService {
  // Implementación básica del servicio Ollama
} 