import { Injectable } from '@nestjs/common';

@Injectable()
export class OpenAIService {
  // Implementación básica del servicio OpenAI
} 