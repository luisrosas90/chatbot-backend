# Backend del Chatbot

Este es el backend de un sistema de chatbot que integra WhatsApp con servicios de IA para proporcionar respuestas inteligentes a los usuarios.

## Características

- Integración con WhatsApp usando Evolution API
- Procesamiento de mensajes de texto, audio e imágenes
- Transcripción de audio usando OpenAI Whisper
- Análisis de imágenes usando OpenAI Vision
- Generación de respuestas usando GPT-3.5
- Almacenamiento de sesiones y mensajes en PostgreSQL
- Documentación API con Swagger

## Requisitos

- Node.js 16+
- PostgreSQL 12+
- Cuenta de Evolution API
- Cuenta de OpenAI

## Instalación

1. Clonar el repositorio:
```bash
git clone https://github.com/your-username/chatbot-backend.git
cd chatbot-backend
```

2. Instalar dependencias:
```bash
npm install
```

3. Configurar variables de entorno:
```bash
cp .env.example .env
# Editar .env con tus credenciales
```

4. Ejecutar migraciones:
```bash
npm run migration:run
```

5. Iniciar el servidor:
```bash
npm run start:dev
```

## Estructura del Proyecto

```
src/
├── ai/                 # Servicios de IA
├── chat/              # Gestión de chat
├── whatsapp/          # Integración con WhatsApp
├── config/            # Configuración
└── main.ts            # Punto de entrada
```

## API Endpoints

### WhatsApp

- `POST /api/whatsapp/webhook` - Webhook para recibir mensajes
- `GET /api/whatsapp/status` - Estado de la conexión
- `POST /api/whatsapp/webhook/configure` - Configurar webhook
- `GET /api/whatsapp/chat/:phoneNumber` - Historial de chat
- `POST /api/whatsapp/chat/:phoneNumber/end` - Finalizar sesión

### Chat

- `POST /api/chat/message` - Procesar mensaje
- `GET /api/chat/history/:phoneNumber` - Obtener historial
- `POST /api/chat/session/:phoneNumber/end` - Finalizar sesión

### IA

- `POST /api/ai/transcribe` - Transcribir audio
- `POST /api/ai/analyze-image` - Analizar imagen
- `POST /api/ai/chat` - Generar respuesta

## Documentación API

La documentación completa de la API está disponible en:
```
http://localhost:3000/api
```

## Desarrollo

### Scripts Disponibles

- `npm run start` - Iniciar en producción
- `npm run start:dev` - Iniciar en desarrollo
- `npm run build` - Compilar
- `npm run test` - Ejecutar pruebas
- `npm run migration:generate` - Generar migración
- `npm run migration:run` - Ejecutar migraciones

### Convenciones de Código

- Usar TypeScript
- Seguir el estilo de código de NestJS
- Documentar con JSDoc
- Escribir pruebas unitarias

## Despliegue

1. Compilar el proyecto:
```bash
npm run build
```

2. Configurar variables de entorno en producción

3. Iniciar el servidor:
```bash
npm run start:prod
```

## Contribuir

1. Fork el repositorio
2. Crear rama feature (`git checkout -b feature/AmazingFeature`)
3. Commit cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abrir Pull Request

## Licencia

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para más detalles. 